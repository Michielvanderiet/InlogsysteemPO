<?php



mysql_connect('localhost', 'root', 'usbw');
mysql_select_db('Eindopdracht_V2');


$admin='admin';



$url_home = 'index.php';


$design = 'default';

include('init.php');
?>